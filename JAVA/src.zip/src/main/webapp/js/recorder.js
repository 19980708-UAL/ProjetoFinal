navigator.mediaDevices.getUserMedia({ audio: true })
    .then(stream => { handlerFunction(stream) })

function handlerFunction(stream) {
    // const mime = ['audio/wav', 'audio/mpeg', 'audio/webm', 'audio/ogg'].filter(MediaRecorder.isTypeSupported)[0];
    rec = new MediaRecorder(stream);
    rec.ondataavailable = e => {
        audioChunks.push(e.data);
        if (rec.state == "inactive") {

            let wav = toWav(audioChunks);
            let blob = new Blob(audioChunks);

            ipaudio(blob)

        }
    }
}

function ipaudio(v_blob) {
    var form = new FormData();
    alert(URL.createObjectURL(v_blob) + ".wav");
    form.append("file", v_blob, URL.createObjectURL(v_blob) + ".wav");
    // form.append("test_id", "7");

    var settings = {
        "url": "http://localhost:5000/audio",
        "method": "POST",
        "timeout": 0,
        "processData": false,
        "mimeType": "multipart/form-data",
        "contentType": false,
        "data": form
    };

    $.ajax(settings).done(function (response) {
        console.log(response);
    });
}


function sendData(data) { }
record.onclick = e => {
    record.disabled = true;
    record.style.display = "none";
    stopRecord.disabled = false;
    stopRecord.style.display = "block";
    document.getElementById("canvas").style.display = "block";
    audioChunks = [];
    rec.start();
}
stopRecord.onclick = e => {
    record.disabled = false;
    record.style.display = "block";
    stopRecord.style.display = "none";
    document.getElementById("canvas").style.display = "none";
    stop.disabled = true;
    rec.stop();

}

/* ************** Medidor de Volume  *************** */
navigator.getUserMedia = navigator.getUserMedia ||
    navigator.webkitGetUserMedia ||
    navigator.mozGetUserMedia;
if (navigator.getUserMedia) {
    navigator.getUserMedia({
        audio: true
    },
        function (stream) {
            audioContext = new AudioContext();
            analyser = audioContext.createAnalyser();
            microphone = audioContext.createMediaStreamSource(stream);
            javascriptNode = audioContext.createScriptProcessor(2048, 1, 1);

            analyser.smoothingTimeConstant = 0.8;
            analyser.fftSize = 1024;

            microphone.connect(analyser);
            analyser.connect(javascriptNode);
            javascriptNode.connect(audioContext.destination);

            canvasContext = $("#canvas")[0].getContext("2d");

            javascriptNode.onaudioprocess = function () {
                var array = new Uint8Array(analyser.frequencyBinCount);
                analyser.getByteFrequencyData(array);
                var values = 0;

                var length = array.length;
                for (var i = 0; i < length; i++) {
                    values += (array[i]);
                }

                var average = values / length;

                //          console.log(Math.round(average - 40));

                canvasContext.clearRect(0, 0, 150, 300);
                canvasContext.fillStyle = '#BadA55';
                canvasContext.fillRect(0, 300 - average, 150, 300);
                canvasContext.fillStyle = '#262626';
                canvasContext.font = "48px impact";
                canvasContext.fillText(Math.round(average - 0), -2, 300);

            } // end fn stream
        },
        function (err) {
            console.log("The following error occured: " + err.name)
        });
} else {
    console.log("getUserMedia not supported");
}
