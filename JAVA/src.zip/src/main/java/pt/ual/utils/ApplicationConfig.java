package pt.ual.utils;

import java.util.Set;
import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("webresources")
public class ApplicationConfig extends Application {

    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<Class<?>>();
        resources.add(pt.ual.views.UserServices.class);
        resources.add(pt.ual.views.CountryService.class);
        resources.add(pt.ual.views.AgeService.class);
        resources.add(pt.ual.views.TestService.class);
        resources.add(pt.ual.views.UploadFileService.class);
        return resources;
    }
}
