
package pt.ual.utils;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class utils {

    public static java.sql.Connection getConnectionStock() throws Exception {
        Context c = new InitialContext();
        try {
            DataSource d = (DataSource) c.lookup("jdbc/app_kof");
            return d.getConnection();
        } catch (Exception ex) {
            throw new Exception("Unable to connect database app_kof");
        }
    }

}
