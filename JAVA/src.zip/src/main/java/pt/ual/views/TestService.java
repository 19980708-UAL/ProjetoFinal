
package pt.ual.views;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import pt.ual.dao.Test;


@Path("test")
public class TestService {

    @Context
    private UriInfo context;

    public TestService() {
    }

//    @GET
//    @Path("/all")
//    @Produces({"application/json"})
//    public Response getCoutrys() throws Exception {
//        Response.ResponseBuilder b = null;
//        Test list = new Test();
//        try {
//            List<Map<String, Object>> row = list.allCountrys();
//            b = Response.ok(row);
//        } catch (Exception ex) {
//            b = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(ex);
//        }
//        return b.build();
//        // http://localhost:8080/KOFKOF/webresources/country/all
//    }

    @GET
    @Path("/usr_id/{usr_id}")
    @Produces({"application/json"})
    public Response record(@PathParam("usr_id") int usr_id) throws Exception {
        boolean result = false;
        Response.ResponseBuilder response = null;
        Test ptr = new Test();
        ptr.setUsr_id(usr_id);
        try {
            response = Response.ok(ptr.tests()).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        // http://localhost:8080/KOFKOF/webresources/test/usr_id/2
    }

       
}

