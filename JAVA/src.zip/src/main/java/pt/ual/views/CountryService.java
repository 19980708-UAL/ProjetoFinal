
package pt.ual.views;

import java.util.List;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import pt.ual.dao.Countrys;


@Path("country")
public class CountryService {

    @Context
    private UriInfo context;

    public CountryService() {
    }

    @GET
    @Path("/all")
    @Produces({"application/json"})
    public Response getCoutrys() throws Exception {
        Response.ResponseBuilder b = null;
        Countrys list = new Countrys();
        try {
            List<Map<String, Object>> row = list.allCountrys();
            b = Response.ok(row);
        } catch (Exception ex) {
            b = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(ex);
        }
        return b.build();
        // http://localhost:8080/KOFKOF/webresources/country/all
    }

    @GET
    @Path("/record/{cnt_id}")
    @Produces({"application/json"})
    public Response record(@PathParam("cnt_id") int cnt_id) throws Exception {
        boolean result = false;
        Response.ResponseBuilder response = null;
        Countrys ptr = new Countrys();
        ptr.setCnt_id(cnt_id);
        try {
            response = Response.ok(ptr.country()).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        // http://localhost:8080/KOFKOF/webresources/country/record/2
    }

//    @POST
//    @Path("/create")
//    @Produces({"application/json"})
//    public Response Create(String data) throws Exception {
//        long id = 0;
//        Response.ResponseBuilder response = null;
//        Items myObj;
//        try {
//            myObj = new ObjectMapper().readValue(data, Items.class);
//            id = myObj.create();
//            response = Response.status(Response.Status.OK).entity(id).header("content-type", "application/json; charset=UTF-8");
//        } catch (Exception ex) {
//            ex.printStackTrace();
//            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(id).header("content-type", "application/json; charset=UTF-8");
//        }
//        return response.build();
    // http://localhost:8080/stocksMS/webresources/items/create
    //{
    //ite_name: "asdas"
    //}        
}
