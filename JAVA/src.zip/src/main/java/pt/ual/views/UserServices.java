package pt.ual.views;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.Map;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import pt.ual.dao.Users;

@Path("users")
public class UserServices {

    @Context
    private UriInfo context;

    public UserServices() {
    }

    @GET
    @Path("/all")
    @Produces({"application/json"})
    public Response getItems() throws Exception {
        Response.ResponseBuilder b = null;
        Users list = new Users();
        try {
            List<Map<String, Object>> row = list.allUsers();
            b = Response.ok(row);
        } catch (Exception ex) {
            b = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(ex);
        }
        return b.build();
        // http://localhost:8080/KOFKOF/webresources/users/all
    }

    @GET
    @Path("/record/{usr_id}")
    @Produces({"application/json"})
    public Response record(@PathParam("usr_id") int usr_id) throws Exception {
        boolean result = false;
        Response.ResponseBuilder response = null;
        Users ptr = new Users();
        ptr.setUsr_id(usr_id);
        try {
            response = Response.ok(ptr.idUser()).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        // http://localhost:8080/KOFKOF/webresources/users/record/2
    }

    @GET
    @Path("/recordDesc/{usr_id}")
    @Produces({"application/json"})
    public Response recordDesc(@PathParam("usr_id") int usr_id) throws Exception {
        boolean result = false;
        Response.ResponseBuilder response = null;
        Users ptr = new Users();
        ptr.setUsr_id(usr_id);
        try {
            response = Response.ok(ptr.idUserDesc()).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        // http://localhost:8080/KOFKOF/webresources/users/recordDesc/2
    }

    @GET
    @Path("/login/{usr}/{pass}")
    @Produces({"application/json"})
    public Response login(@PathParam("usr") String usr, @PathParam("pass") String pass) throws Exception {
        boolean result = false;
        Response.ResponseBuilder response = null;
        Users ptr = new Users();
        try {
            response = Response.ok(ptr.login(usr, pass)).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        // http://localhost:8080/KOFKOF/webresources/users/login/upinto/123456789
    }

    @POST
    @Path("/create")
    @Produces({"application/json"})
    public Response Create(String data) throws Exception {
        long id = 0;
        Response.ResponseBuilder response = null;
        Users myObj;
        try {
            myObj = new ObjectMapper().readValue(data, Users.class);
            id = myObj.create();
            response = Response.status(Response.Status.OK).entity(id).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(id).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
//     http://localhost:8080/KOFKOF/webresources/users/create
//        {
//          "usr_user": "asdas",
//          "usr_name": "dddddd",
//          "usr_password": "2222",
//          "usr_email": "asdas@sddd.pt",
//          "usr_age": "12",
//          "usr_country": "1"
//}       
    }

    @PUT
    @Path("/update")
    @Produces({"application/json"})
    public Response userUpdate(String data) throws Exception {
        long id = 0;
        //Resposta r = new Resposta();
        Response.ResponseBuilder response = null;
        Users myObj;
        try {
            myObj = new ObjectMapper().readValue(data, Users.class);
            id = myObj.update();
            response = Response.status(Response.Status.OK).entity(id).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(ex.getMessage()).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        //     http://localhost:8080/KOFKOF/webresources/users/update
//        {
//          "usr_id": "3",
//          "usr_user": "asdas",
//          "usr_name": "dddddd",
//          "usr_password": "2222",
//          "usr_email": "asdas@sddd.pt",
//          "usr_age": "12",
//          "usr_country": "1"
//}      
    }

}
