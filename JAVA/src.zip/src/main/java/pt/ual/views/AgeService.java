
package pt.ual.views;

import java.util.List;
import java.util.Map;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import pt.ual.dao.Age;


@Path("age")
public class AgeService {

    @Context
    private UriInfo context;

    public AgeService() {
    }

    @GET
    @Path("/all")
    @Produces({"application/json"})
    public Response getCoutrys() throws Exception {
        Response.ResponseBuilder b = null;
        Age list = new Age();
        try {
            List<Map<String, Object>> row = list.allAges();
            b = Response.ok(row);
        } catch (Exception ex) {
            b = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(ex);
        }
        return b.build();
        // http://localhost:8080/KOFKOF/webresources/age/all
    }

    @GET
    @Path("/record/{age_id}")
    @Produces({"application/json"})
    public Response record(@PathParam("age_id") int age_id) throws Exception {
        boolean result = false;
        Response.ResponseBuilder response = null;
        Age ptr = new Age();
        ptr.setAge_id(age_id);
        try {
            response = Response.ok(ptr.age()).header("content-type", "application/json; charset=UTF-8");
        } catch (Exception ex) {
            ex.printStackTrace();
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(result).header("content-type", "application/json; charset=UTF-8");
        }
        return response.build();
        // http://localhost:8080/KOFKOF/webresources/age/record/2
    }
   
}

