package pt.ual.views;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.Part;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.ContentBody;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import static org.glassfish.jersey.message.internal.CommittingOutputStream.DEFAULT_BUFFER_SIZE;
import pt.ual.dao.Sound;
import pt.ual.dao.Test;

@Path("/fileUpload")

public class UploadFileService {

    @Context
    HttpServletRequest req;

    public UploadFileService() {
    }

    @POST
    @Path("/upload")
    @Consumes(MediaType.MULTIPART_FORM_DATA)
    public Response uploadFile() throws IOException, ServletException, Exception {

        int usr_id = Integer.valueOf(req.getParameter("usr_id"));
        String test_result = String.valueOf(req.getParameter("test_result"));
        Part filePart = req.getPart("file");

        //inserir teste
        Test test = new Test();
        int test_id = test.create(usr_id, test_result, "");

        // Inserir ficheiro
        InputStream fileContent = filePart.getInputStream();
        Sound sound = new Sound(test_id, fileContent);
        sound.create();

        return Response.status(200).entity("Inserido com sucesso. ID = " + test_id).build();
    }

}
