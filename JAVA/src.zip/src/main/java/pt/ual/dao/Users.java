package pt.ual.dao;

import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import pt.ual.utils.utils;

public class Users {

    private int usr_id;
    private String usr_user;
    private String usr_name;
    private String usr_password;
    private String usr_email;
    private int usr_age;
    private String age_year;
    private int usr_country;
    private String cnt_desc;

    public Users() {
    }

    public int getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(int usr_id) {
        this.usr_id = usr_id;
    }

    public String getUsr_user() {
        return usr_user;
    }

    public void setUsr_user(String usr_user) {
        this.usr_user = usr_user;
    }

    public String getUsr_name() {
        return usr_name;
    }

    public void setUsr_name(String usr_name) {
        this.usr_name = usr_name;
    }

    public String getUsr_password() {
        return usr_password;
    }

    public void setUsr_password(String usr_password) {
        this.usr_password = usr_password;
    }

    public String getUsr_email() {
        return usr_email;
    }

    public void setUsr_email(String usr_email) {
        this.usr_email = usr_email;
    }

    public int getUsr_age() {
        return usr_age;
    }

    public void setUsr_age(int usr_age) {
        this.usr_age = usr_age;
    }

    public String getAge_year() {
        return age_year;
    }

    public void setAge_year(String age_year) {
        this.age_year = age_year;
    }
    
    

    public int getUsr_country() {
        return usr_country;
    }

    public void setUsr_country(int usr_country) {
        this.usr_country = usr_country;
    }

    public String getCnt_desc() {
        return cnt_desc;
    }

    public void setCnt_desc(String cnt_desc) {
        this.cnt_desc = cnt_desc;
    }
    
    

    public List<Map<String, Object>> allUsers() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        List<Map<String, Object>> listItems = new ArrayList<Map<String, Object>>();
        try {
            c = utils.getConnectionStock();
            String q = "select * from tapr_user";
            ps = c.prepareStatement(q);
            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                Map<String, Object> maps = new LinkedHashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    String name = rsmd.getColumnName(i);
                    maps.put(name, rs.getString(name));
                }
                listItems.add(maps);
            }
            rs = ps.executeQuery();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return listItems;
    }

    /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    public Users idUser() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;
        Users u = new Users();
        try {
            c = utils.getConnectionStock();
            q = "select USR_ID, USR_USER, USR_NAME, USR_PASSWORD, USR_EMAIL, USR_AGE, USR_COUNTRY from tapr_user where usr_id = ? ";
            ps = c.prepareStatement(q);
            ps.setInt(1, this.usr_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                u.setUsr_id(rs.getInt(1));
                u.setUsr_user(rs.getString(2));
                u.setUsr_name(rs.getString(3));
                u.setUsr_password(rs.getString(4));
                u.setUsr_email(rs.getString(5));
                u.setUsr_age(rs.getInt(6));
                u.setUsr_country(rs.getInt(7));
            }
            rs.close();
            ps.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return u;
    }
    
    
        /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    public Users idUserDesc() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;
        Users u = new Users();
        try {
            c = utils.getConnectionStock();
            q = "select usr_id, usr_user, usr_name, usr_password, usr_email, age_year, cnt_desc"
                    + " from tapr_user us, tapr_age ag, tapr_country co "
                    + " where us.usr_age = ag.age_id and us.usr_country = co.cnt_id and usr_id = ? ";
            ps = c.prepareStatement(q);
            ps.setInt(1, this.usr_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                u.setUsr_id(rs.getInt(1));
                u.setUsr_user(rs.getString(2));
                u.setUsr_name(rs.getString(3));
                u.setUsr_password(rs.getString(4));
                u.setUsr_email(rs.getString(5));
                u.setAge_year(rs.getString(6));
                u.setCnt_desc(rs.getString(7));
            }
            rs.close();
            ps.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return u;
    }

    /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    public int login(String user, String pass) throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;
        int u;
        try {
            c = utils.getConnectionStock();
            q = "select max(usr_id) from tapr_user "
                    + " where usr_user = '" + user + "' and usr_password = '" + pass + "' ";
            ps = c.prepareStatement(q);
            rs = ps.executeQuery();

            int vCount;
            rs.next();
            vCount = rs.getInt(1);

            if (vCount != 0) {
                u = vCount;
            } else {
                u = 0;
            }

            rs.close();
            ps.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return u;
    }

    /////////////////////////////////////////////////////////////////////
    ///////////////////////   INSERT   //////////////////////////////////
    public long create() throws Exception {
        long toRet = 0;
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;

        try {
            c = utils.getConnectionStock();
            c.setAutoCommit(false);
            String q = "INSERT INTO tapr_user (USR_USER, USR_NAME, USR_PASSWORD, USR_EMAIL, USR_AGE, USR_COUNTRY) "
                    + "VALUES(?,?,?,?,?,?)";

            ps = c.prepareStatement(q, new String[]{"usr_id"});
            ps.setObject(1, this.usr_user);
            ps.setObject(2, this.usr_name);
            ps.setObject(3, this.usr_password);
            ps.setObject(4, this.usr_email);
            ps.setObject(5, this.usr_age);
            ps.setObject(6, this.usr_country);

            if (ps.executeUpdate() > 0) {
                rs = ps.getGeneratedKeys();
                if (null != rs && rs.next()) {
                    toRet = rs.getLong(1);
                    c.commit();
                }
            }

        } catch (SQLException ex) {
            c.rollback();
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return toRet;

    }

    /////////////////////////////////////////////////////////////////////
    ///////////////////////   UPDATE   //////////////////////////////////
    public long update() throws Exception {
        long updatedId = 0;
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;

        try {
            c = utils.getConnectionStock();
            c.setAutoCommit(false);
            q = "UPDATE tapr_user SET "
                    + " USR_USER = ?"
                    + " , USR_NAME = ?"
                    + " , USR_PASSWORD = ?"
                    + " , USR_EMAIL = ?"
                    + " , USR_AGE = ?"
                    + " , USR_COUNTRY = ?"
                    + " where usr_id = ?";

            ps = c.prepareStatement(q);
            ps.setObject(1, this.usr_user);
            ps.setObject(2, this.usr_name);
            ps.setObject(3, this.usr_password);
            ps.setObject(4, this.usr_email);
            ps.setLong(5, this.usr_age);
            ps.setLong(6, this.usr_country);
            ps.setLong(7, this.usr_id);

            ps.executeUpdate();

            updatedId = this.usr_id;
            //if (ps. .execute()) {
            //rs = ps.getGeneratedKeys();
            //if (null != rs && rs.next()) {
            c.commit();
            //}
            //}

        } catch (SQLException ex) {
            c.rollback();
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return updatedId;

    }

}
