package pt.ual.dao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import pt.ual.utils.utils;

public class Test {

    private int test_id;
    private int usr_id;
    private String test_result;
    private String test_trust_rating;

    public Test() {
    }

    public int getTest_id() {
        return test_id;
    }

    public void setTest_id(int test_id) {
        this.test_id = test_id;
    }

    public int getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(int usr_id) {
        this.usr_id = usr_id;
    }

    public String getTest_result() {
        return test_result;
    }

    public void setTest_result(String test_result) {
        this.test_result = test_result;
    }

    public String getTest_trust_rating() {
        return test_trust_rating;
    }

    public void setTest_trust_rating(String test_trust_rating) {
        this.test_trust_rating = test_trust_rating;
    }

    /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    public ArrayList<Test> tests() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;
        ArrayList<Test> list = new ArrayList<Test>();
        try {
            c = utils.getConnectionStock();
            q = "select test_id, test_result, test_trust_rating from tapr_test where usr_id = ? ";
            ps = c.prepareStatement(q);
            ps.setInt(1, this.usr_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                Test u = new Test();
                u.setTest_id(rs.getInt(1));
                u.setTest_result(rs.getString(2));
                u.setTest_trust_rating(rs.getString(3));
                list.add(u);
            }
            rs.close();
            ps.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return list;
    }

    /////////////////////////////////////////////////////////////////////
    ///////////////////////   INSERT   //////////////////////////////////
    public int create(int usr_id, String test_result, String test_trust_rating) throws Exception {

        java.sql.Connection c = null;
        //java.sql.PreparedStatement ps = null;
        PreparedStatement pstmt = null;
        java.sql.ResultSet rs = null;
        int primkey = 0;

        try {
            c = utils.getConnectionStock();
            //c.setAutoCommit(false);
            String insertSQL = "insert into app_kof.tapr_test (usr_id, test_result, test_trust_rating) "
                    + "VALUES(?,?,?)";
//
//            String[] returnId = { "test_id" };
//            ps = c.prepareStatement(q, returnId);
//            //ps = c.prepareStatement(q);
//
//            if (ps.executeUpdate() > 0) {
//                rs = ps.getGeneratedKeys();
//                if (null != rs && rs.next()) {
//                    toRet = rs.getInt(1);
//                    c.commit();
//                }
//            }
            String columnNames[] = new String[]{"test_id"};

            //ps = c.prepareStatement(q, columnNames);
            pstmt = c.prepareStatement( insertSQL, columnNames );
            pstmt.setInt(1, usr_id);
            pstmt.setString(2, test_result);
            pstmt.setString(3, test_trust_rating);

            if (pstmt.executeUpdate() > 0) {
                // Retrieves any auto-generated keys created as a result of executing this Statement object
                java.sql.ResultSet generatedKeys = pstmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    primkey = generatedKeys.getInt(1);
                    //c.commit();
                }
            }
            System.out.println("Record updated with id = " + primkey);

        } catch (SQLException ex) {
            c.rollback();
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return primkey;

    }

}
