package pt.ual.dao;

import java.io.InputStream;
import java.sql.SQLException;
import pt.ual.utils.utils;

public class Sound {

    private int test_id;
    private InputStream snd_sounds;

    public Sound() {
    }

    public Sound(int test_id, InputStream snd_sounds) {
        this.test_id = test_id;
        this.snd_sounds = snd_sounds;
    }

    /////////////////////////////////////////////////////////////////////
    ///////////////////////   INSERT   //////////////////////////////////
    public long create() throws Exception {
        long toRet = 0;
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;

        try {
            c = utils.getConnectionStock();
            c.setAutoCommit(false);
            String q = "INSERT INTO tapr_sound (test_id, snd_sounds) "
                    + "VALUES(?,?)";

            ps = c.prepareStatement(q);
            ps.setObject(1, this.test_id);

            //FileInputStream fis = new FileInputStream(image);
            //ps.setBinaryStream(2, this.snd_sounds);
            ps.setBlob(2, this.snd_sounds);

            //ps.registerOutParameter(8, OracleTypes.INTEGER);
            ps.execute();
            c.commit();

            //result = ps.getInt(1);

        } catch (SQLException ex) {
            c.rollback();
            ex.printStackTrace();
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return toRet;

    }

}
