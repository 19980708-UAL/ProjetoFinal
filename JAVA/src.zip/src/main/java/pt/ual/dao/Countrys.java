/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ual.dao;

import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import pt.ual.utils.utils;


public class Countrys {
    
    private int cnt_id;
    private String cnt_desc;

    public Countrys() {
    }

    public int getCnt_id() {
        return cnt_id;
    }

    public void setCnt_id(int cnt_id) {
        this.cnt_id = cnt_id;
    }

    public String getCnt_desc() {
        return cnt_desc;
    }

    public void setCnt_desc(String cnt_desc) {
        this.cnt_desc = cnt_desc;
    }
    
    
        public List<Map<String, Object>> allCountrys() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        List<Map<String, Object>> listCountrys = new ArrayList<Map<String, Object>>();
        try {
            c = utils.getConnectionStock();
            String q = "select * from tapr_country";
            ps = c.prepareStatement(q);
            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                Map<String, Object> countrys = new LinkedHashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    String name = rsmd.getColumnName(i);
                    countrys.put(name, rs.getString(name));
                }
                listCountrys.add(countrys);
            }
            rs = ps.executeQuery();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return listCountrys;
    }
        
        
    /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    public Countrys country() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;
        Countrys u = new Countrys();
        try {
            c = utils.getConnectionStock();
            q = "select cnt_id, cnt_desc from tapr_country where cnt_id = ? ";
            ps = c.prepareStatement(q);
            ps.setInt(1, this.cnt_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                u.setCnt_id(rs.getInt(1));
                u.setCnt_desc(rs.getString(2));
            }
            rs.close();
            ps.close();
            
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return u;
    }
        
    
}
