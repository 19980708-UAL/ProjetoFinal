/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pt.ual.dao;

import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import pt.ual.utils.utils;


public class Age {
    
    private int age_id;
    private int age_year;

    public Age() {
    }

    public int getAge_id() {
        return age_id;
    }

    public void setAge_id(int age_id) {
        this.age_id = age_id;
    }

    public int getAge_year() {
        return age_year;
    }

    public void setAge_year(int age_year) {
        this.age_year = age_year;
    }
    
    
    /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    
       public List<Map<String, Object>> allAges() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        List<Map<String, Object>> listAges = new ArrayList<Map<String, Object>>();
        try {
            c = utils.getConnectionStock();
            String q = "select * from tapr_age";
            ps = c.prepareStatement(q);
            rs = ps.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount();

            while (rs.next()) {
                Map<String, Object> ages = new LinkedHashMap<String, Object>();
                for (int i = 1; i <= columnCount; i++) {
                    String name = rsmd.getColumnName(i);
                    ages.put(name, rs.getString(name));
                }
                listAges.add(ages);
            }
            rs = ps.executeQuery();
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return listAges;
    }
        
        
    /////////////////////////////////////////////////////////////////////
    /////////////////////////////////////////////////////////////////////
    public Age age() throws Exception {
        java.sql.Connection c = null;
        java.sql.PreparedStatement ps = null;
        java.sql.ResultSet rs = null;
        String q;
        Age u = new Age();
        try {
            c = utils.getConnectionStock();
            q = "select age_id, age_year from tapr_age where age_id = ? ";
            ps = c.prepareStatement(q);
            ps.setInt(1, this.age_id);
            rs = ps.executeQuery();

            while (rs.next()) {
                u.setAge_id(rs.getInt(1));
                u.setAge_year(rs.getInt(2));
            }
            rs.close();
            ps.close();
            
        } catch (Exception ex) {
            ex.printStackTrace();
            throw ex;
        } finally {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (c != null) {
                c.close();
            }
        }
        return u;
    }
    
    
    
    
}
